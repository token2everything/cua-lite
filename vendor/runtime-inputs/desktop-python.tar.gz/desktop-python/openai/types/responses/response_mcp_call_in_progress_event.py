# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["ResponseMcpCallInProgressEvent"]


class ResponseMcpCallInProgressEvent(BaseModel):
    """Emitted when an MCP  tool call is in progress."""

    item_id: str
    """The unique identifier of the MCP tool call item being processed."""

    output_index: int
    """The index of the output item in the response's output array."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.mcp_call.in_progress"]
    """The type of the event. Always 'response.mcp_call.in_progress'."""
