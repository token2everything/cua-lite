# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable, Optional
from typing_extensions import Literal, Required, TypedDict

from .response_input_item_param import ResponseInputItemParam

__all__ = ["ResponseCompactParams", "PromptCacheOptions"]


class ResponseCompactParams(TypedDict, total=False):
    model: Required[
        Union[
            Literal[
                "gpt-6-astra",
                "gpt-6-sol",
                "gpt-6-luna",
                "gpt-5.6-sol",
                "gpt-5.6-terra",
                "gpt-5.6-luna",
                "gpt-5.5",
                "gpt-5.5-2026-04-23",
                "gpt-5.4",
                "gpt-5.4-mini",
                "gpt-5.4-nano",
                "gpt-5.4-mini-2026-03-17",
                "gpt-5.4-nano-2026-03-17",
                "gpt-5.3-chat-latest",
                "gpt-5.2",
                "gpt-5.2-2025-12-11",
                "gpt-5.2-chat-latest",
                "gpt-5.2-pro",
                "gpt-5.2-pro-2025-12-11",
                "gpt-5.1",
                "gpt-5.1-2025-11-13",
                "gpt-5.1-codex",
                "gpt-5.1-mini",
                "gpt-5.1-chat-latest",
                "gpt-5",
                "gpt-5-mini",
                "gpt-5-nano",
                "gpt-5-2025-08-07",
                "gpt-5-mini-2025-08-07",
                "gpt-5-nano-2025-08-07",
                "gpt-5-chat-latest",
                "gpt-4.1",
                "gpt-4.1-mini",
                "gpt-4.1-nano",
                "gpt-4.1-2025-04-14",
                "gpt-4.1-mini-2025-04-14",
                "gpt-4.1-nano-2025-04-14",
                "o4-mini",
                "o4-mini-2025-04-16",
                "o3",
                "o3-2025-04-16",
                "o3-mini",
                "o3-mini-2025-01-31",
                "o1",
                "o1-2024-12-17",
                "o1-preview",
                "o1-preview-2024-09-12",
                "o1-mini",
                "o1-mini-2024-09-12",
                "gpt-4o",
                "gpt-4o-2024-11-20",
                "gpt-4o-2024-08-06",
                "gpt-4o-2024-05-13",
                "gpt-audio-mini",
                "gpt-audio-mini-2025-12-15",
                "gpt-4o-audio-preview",
                "gpt-4o-audio-preview-2024-10-01",
                "gpt-4o-audio-preview-2024-12-17",
                "gpt-4o-audio-preview-2025-06-03",
                "gpt-4o-mini-audio-preview",
                "gpt-4o-mini-audio-preview-2024-12-17",
                "gpt-4o-search-preview",
                "gpt-4o-mini-search-preview",
                "gpt-4o-search-preview-2025-03-11",
                "gpt-4o-mini-search-preview-2025-03-11",
                "chatgpt-4o-latest",
                "codex-mini-latest",
                "gpt-4o-mini",
                "gpt-4o-mini-2024-07-18",
                "gpt-4-turbo",
                "gpt-4-turbo-2024-04-09",
                "gpt-4-0125-preview",
                "gpt-4-turbo-preview",
                "gpt-4-1106-preview",
                "gpt-4-vision-preview",
                "gpt-4",
                "gpt-4-0314",
                "gpt-4-0613",
                "gpt-4-32k",
                "gpt-4-32k-0314",
                "gpt-4-32k-0613",
                "gpt-3.5-turbo",
                "gpt-3.5-turbo-16k",
                "gpt-3.5-turbo-0301",
                "gpt-3.5-turbo-0613",
                "gpt-3.5-turbo-1106",
                "gpt-3.5-turbo-0125",
                "gpt-3.5-turbo-16k-0613",
                "o1-pro",
                "o1-pro-2025-03-19",
                "o3-pro",
                "o3-pro-2025-06-10",
                "o3-deep-research",
                "o3-deep-research-2025-06-26",
                "o4-mini-deep-research",
                "o4-mini-deep-research-2025-06-26",
                "computer-use-preview",
                "computer-use-preview-2025-03-11",
                "gpt-5.5-pro",
                "gpt-5.5-pro-2026-04-23",
                "gpt-5-codex",
                "gpt-5-pro",
                "gpt-5-pro-2025-10-06",
                "gpt-5.1-codex-max",
                "gpt-daybreak-blue-latest",
                "gpt-daybreak-red-latest",
                "gpt-5.6-cyber",
                "gpt-rosalind-research",
            ],
            str,
            None,
        ]
    ]
    """Model ID used to generate the response, like `gpt-6-astra`.

    OpenAI offers a wide range of models with different capabilities, performance
    characteristics, and price points. Refer to the
    [model guide](https://developers.openai.com/api/docs/models) to browse and
    compare available models.
    """

    input: Union[str, Iterable[ResponseInputItemParam], None]
    """Text, image, or file inputs to the model, used to generate a response"""

    instructions: Optional[str]
    """
    A system (or developer) message inserted into the model's context. When used
    along with `previous_response_id`, the instructions from a previous response
    will not be carried over to the next response. This makes it simple to swap out
    system (or developer) messages in new responses.
    """

    previous_response_id: Optional[str]
    """The unique ID of the previous response to the model.

    Use this to create multi-turn conversations. Learn more about
    [conversation state](https://developers.openai.com/api/docs/guides/conversation-state).
    Cannot be used in conjunction with `conversation`.
    """

    prompt_cache_key: Optional[str]
    """A key to use when reading from or writing to the prompt cache."""

    prompt_cache_options: Optional[PromptCacheOptions]
    """Options for prompt caching.

    Supported for `gpt-5.6` and later models. By default, OpenAI automatically
    chooses one implicit cache breakpoint. You can add explicit breakpoints to
    content blocks with `prompt_cache_breakpoint`. Each request can write up to four
    breakpoints. For cache matching, OpenAI considers up to the latest 80
    breakpoints in the conversation, without a content-block lookback limit. Set
    `mode` to `explicit` to disable the implicit breakpoint. The `ttl` defaults to
    `30m`, which is currently the only supported value. See the
    [prompt caching guide](https://developers.openai.com/api/docs/guides/prompt-caching)
    for current details.
    """

    prompt_cache_retention: Optional[Literal["in_memory", "24h"]]
    """How long to retain a prompt cache entry created by this request."""

    service_tier: Optional[Literal["auto", "default", "fast", "flex", "priority"]]
    """Specifies the processing type used for serving the request.

    - If set to 'auto', then the request will be processed with the service tier
      configured in the Project settings. Unless otherwise configured, the Project
      will use 'default'. - If set to 'default', then the request will be processed
      with the standard pricing and performance for the selected model. - If set to
      '[flex](https://developers.openai.com/api/docs/guides/flex-processing)', then
      the request will be processed with the Flex Processing service tier. - To
      opt-in to [Fast mode](https://developers.openai.com/api/docs/guides/fast-mode)
      at the request level, include the `service_tier=fast` or
      `service_tier=priority` parameter for Responses or Chat Completions. For
      models with a dedicated Fast tier, either value resolves to
      `service_tier=fast`; for other models, either value resolves to
      `service_tier=priority`. - When not set, the default behavior is 'auto'. When
      the `service_tier` parameter is set, the response body will include the
      `service_tier` value based on the processing mode actually used to serve the
      request. This response value may be different from the value set in the
      parameter.
    """


class PromptCacheOptions(TypedDict, total=False):
    """Options for prompt caching.

    Supported for `gpt-5.6` and later models. By default, OpenAI automatically chooses one implicit cache breakpoint. You can add explicit breakpoints to content blocks with `prompt_cache_breakpoint`. Each request can write up to four breakpoints. For cache matching, OpenAI considers up to the latest 80 breakpoints in the conversation, without a content-block lookback limit. Set `mode` to `explicit` to disable the implicit breakpoint. The `ttl` defaults to `30m`, which is currently the only supported value. See the [prompt caching guide](https://developers.openai.com/api/docs/guides/prompt-caching) for current details.
    """

    mode: Literal["implicit", "explicit"]
    """Controls whether OpenAI automatically creates an implicit cache breakpoint.

    Defaults to `implicit`. With `implicit`, OpenAI creates one implicit breakpoint
    and writes up to the latest three explicit breakpoints in the request. With
    `explicit`, OpenAI does not create an implicit breakpoint and writes up to the
    latest four explicit breakpoints. If there are no explicit breakpoints, the
    request does not use prompt caching.
    """

    ttl: Literal["30m"]
    """
    The minimum lifetime applied to every implicit and explicit cache breakpoint
    written by the request. Defaults to `30m`, which is currently the only supported
    value. The backend may retain cache entries for longer.
    """
