# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["ResponseMcpListToolsInProgressEvent"]


class ResponseMcpListToolsInProgressEvent(BaseModel):
    """
    Emitted when the system is in the process of retrieving the list of available MCP tools.
    """

    item_id: str
    """The ID of the MCP tool call item that is being processed."""

    output_index: int
    """The index of the output item that is being processed."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.mcp_list_tools.in_progress"]
    """The type of the event. Always 'response.mcp_list_tools.in_progress'."""
